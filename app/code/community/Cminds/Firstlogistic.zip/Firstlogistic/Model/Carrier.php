<?php

class Cminds_Firstlogistic_Model_Carrier
    extends Mage_Shipping_Model_Carrier_Abstract
        implements Mage_Shipping_Model_Carrier_Interface
{
    protected $_code = 'cminds_vendor_firstlogistic_shipping';

    public function getAllowedMethods()
    {
        return array(
            'standard' => 'Standard delivery',
        );
    }

    public function collectRates(Mage_Shipping_Model_Rate_Request $request)
    {
        if (!$this->getConfigFlag('active')) {
            return false;
        }

        $result = Mage::getModel('shipping/rate_result');
        $method = Mage::getModel('shipping/rate_result_method');

        $method->setCarrier('cminds_vendor_firstlogistic_shipping');
        $method->setCarrierTitle($this->getConfigData('title'));
        $method->setMethod('cminds_vendor_firstlogistic_shipping');
        $method->setMethodTitle($this->getConfigData('name'));
        $method->setPrice(6.00);
        $result->append($method);
        $this->_result = $result;

        return $this->getResult();
    }

    protected function _getStandardRate()
    {
        /** @var Mage_Shipping_Model_Rate_Result_Method $rate */
        $rate = Mage::getModel('shipping/rate_result_method');

        $rate->setCarrier($this->_code);
        $rate->setCarrierTitle($this->getConfigData('title'));
        $rate->setMethod('large');
        $rate->setMethodTitle('Standard delivery');
        $rate->setPrice(1.23);
        $rate->setCost(0);

        return $rate;
    }
}