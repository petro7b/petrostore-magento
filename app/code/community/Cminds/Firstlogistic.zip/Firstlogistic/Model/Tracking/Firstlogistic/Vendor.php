<?php

class Cminds_Firstlogistic_Model_Tracking_Firtslogistic_Vendor extends Cminds_Firstlogistic_Model_Tracking_Firstlogistic
{
    protected function applyFilters($items) {
        foreach($items AS $k => $item) {
            if(!Mage::helper("marketplace")->isOwner($item->getProduct(), $this->getVendor()->getId())) {
                unset($items[$k]);
            }
        }
    }
}