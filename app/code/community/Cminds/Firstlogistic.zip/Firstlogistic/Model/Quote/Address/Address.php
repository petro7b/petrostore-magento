<?php
    class Cminds_Firstlogistic_Model_Sales_Quote_Address extends Mage_Sales_Model_Quote_Address {

    }