<?php

class Cminds_Firstlogistic_Model_Resource_Setup extends Mage_Customer_Model_Resource_Setup
{
}
