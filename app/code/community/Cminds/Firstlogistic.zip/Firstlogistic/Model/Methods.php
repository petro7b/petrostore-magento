<?php

class Cminds_Firstlogistic_Model_Methods extends Cminds_Marketplace_Model_Methods
{
    public function isFirstlogistic()
    {
        return (bool)$this->getFirstlogistic();
    }

    public function requestFirstlogisticRates($items)
    {
        $firstlogisticModel = Mage::getModel("cminds_firstlogistic/shipping_firstlogistic");
        $requestModel = Mage::getModel('shipping/rate_request');
        $_items = array();
        $vendor_id = false;
        foreach ($items as $item) {
            $_item = Mage::getModel("catalog/product")->load($item->getProductId());
            $vendor_id = Mage::helper('marketplace')->getProductSupplierId($_item);
            $_items[] = $_item;
        }
        $requestModel->setAllItems($_items);
        $requestModel->setVendorId($vendor_id);

        $result = $firstlogisticModel->collectRates($requestModel);

        return $result;
    }
}