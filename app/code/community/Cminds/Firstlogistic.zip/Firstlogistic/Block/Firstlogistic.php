<?php

class Cminds_Firstlogistic_Block_Firstlogistic extends Mage_Core_Block_Template
{
    public function getFormAction()
    {
        return $this->getUrl('marketplace/firstlogistic/post');
    }
}
